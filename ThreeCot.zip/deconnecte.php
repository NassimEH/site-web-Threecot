<?php	
  include './head.php';
	include "./restriction.php";
	session_destroy();

?>

<div class="container">
	
	<h1>Vous êtes déconnecté</h1>


	<a href="accueil.php"><button class="bouton">Retour au menu</button></a>
	
</div>
			
<?php
	include './foot.php';
?>