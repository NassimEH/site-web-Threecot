<?php
include 'accueil.php';
?>
