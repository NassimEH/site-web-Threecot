<?php
include './head.php';
?>
    <div class="container" id="profil"><h1>Bienvenue sur le site Threecot,</h1><br>
    <p> Un endroit merveilleux où les passionnés.ées de tricot et de laine se réunissent pour échanger autour de cet univers incroyable, et accessoirement autour d'un café chaud et réconfortant préparé par Gab et apporté par Marjorie pendant que Nassim s'occupe de faire la vaisselle et nettoyer la maison <br>
      Nous vous attendons patiemment et avec un grand sourire radieux <br></p><br>
		
			<h3> La paix et le calme sur la planète Terre. </h3></div>

<?php
include './foot.php';
?>
